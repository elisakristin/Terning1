/**
 * 
 */
/**
 * @author A
 *
 */
package terning;