# Terning
This is a Java program for rolling dice.
The program has known errors. 

## Purpose
This is an exercise in using _GIT_ to fix errors and trace the changes.
